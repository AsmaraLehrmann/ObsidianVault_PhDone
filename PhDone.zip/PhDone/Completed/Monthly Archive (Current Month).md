# Completed — This Month (Automatic)

> Automatically lists only the tasks you completed **this month** (grouped by day).
> Requires **Dataview**.

```dataviewjs
// ---- Config: current month range ----
const now   = dv.luxon.DateTime.local();
const start = now.startOf('month');
const end   = now.endOf('month');

// Prefer t.completion; fall back to t.done (some setups use this)
const getDoneDt = (t) => t?.completion ?? t?.done ?? null;

// Keep tasks that are completed AND have a valid Luxon DateTime
const done = dv.pages()
  .flatMap(p => p.file.tasks)
  .filter(t => t.completed)
  .map(t => ({...t, _dt: getDoneDt(t)}))
  .filter(t => t._dt && typeof t._dt.toISODate === 'function')
  .filter(t => t._dt >= start && t._dt <= end);

if (done.length === 0) {
  dv.paragraph('_No completions yet this month_');
} else {
  // Group by ISO day string, newest first
  const byDay = dv.array(done)
    .groupBy(t => t._dt.toISODate())
    .sort((a, b) => String(b.key ?? '').localeCompare(String(a.key ?? '')));

  for (const d of byDay) {
    const day = dv.luxon.DateTime.fromISO(String(d.key));
    dv.header(3, day.toFormat('cccc — LLL dd'));
    dv.taskList(d.rows, true);
  }
}

```
