# Completed — This Month (Automatic)

> Automatically lists only the tasks you completed **this month** (grouped by day).
> Requires **Dataview**.

```dataviewjs
const now = dv.luxon.DateTime.local();
const start = now.startOf('month');
const end = now.endOf('month');
const done = dv.pages().flatMap(p => p.file.tasks)
  .where(t => t.completed && t.completion && t.completion >= start && t.completion <= end);

if (done.length === 0) {
  dv.paragraph('_No completions yet this month_');
} else {
  const byDay = dv.array(done).groupBy(t => t.completion.toISODate())
    .sort((a,b) => b.key.localeCompare(a.key));
  for (const d of byDay) {
    const dt = dv.luxon.DateTime.fromISO(d.key);
    dv.header(3, dt.toFormat('cccc — LLL dd'));
    dv.taskList(d.rows, true);
  }
}
```
