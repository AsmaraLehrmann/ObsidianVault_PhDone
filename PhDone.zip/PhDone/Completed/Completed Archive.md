# Completed Archive (Automatic, all months)

> This page **automatically** lists every completed task in your vault, grouped by **month**. No manual filing needed.
> Requires **Dataview**. Works with Tasks plugin metadata (completion date).

```dataviewjs
// Collect all completed tasks with a completion date
const done = dv.pages().flatMap(p => p.file.tasks)
  .where(t => t.completed && t.completion);

// Group by YYYY-MM and sort newest first
function ym(dt){ return dt.toFormat('yyyy-LL'); }
const groups = dv.array(done).groupBy(t => ym(t.completion))
  .sort((a,b) => b.key.localeCompare(a.key));

for (const g of groups) {
  const sample = g.rows[0];
  const y = sample.completion.toFormat('yyyy');
  const mLong = sample.completion.toFormat('LLLL');
  dv.header(2, `${mLong} ${y}`);
  // Group within month by day
  const byDay = dv.array(g.rows).groupBy(t => t.completion.toISODate())
    .sort((a,b) => b.key.localeCompare(a.key)); // newest day first
  for (const d of byDay) {
    const dt = dv.luxon.DateTime.fromISO(d.key);
    dv.header(3, dt.toFormat('cccc — LLL dd'));
    dv.taskList(d.rows, true);
  }
}
```
