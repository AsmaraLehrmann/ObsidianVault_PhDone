# Completed Archive (Automatic, all months)

> This page **automatically** lists every completed task in your vault, grouped by **month**. No manual filing needed.
> Requires **Dataview**. Works with Tasks plugin metadata (completion date).

```dataviewjs
// Get all completed tasks from the vault
const tasks = dv.pages().flatMap(p => p.file.tasks).where(t => t.completed);

// Prefer t.completion (Dataview/Tasks), fall back to t.done if present
function taskDoneDate(t) {
  return t.completion ?? t.done ?? null; // Luxon DateTime or null
}

// YYYY-MM key
function ym(dt) { return dt.toFormat('yyyy-LL'); }

// Keep only tasks that have a real completion date object
const done = tasks.filter(t => taskDoneDate(t));

// Group by month (YYYY-MM) and sort newest month first (string compare)
const groups = dv.array(done)
  .groupBy(t => ym(taskDoneDate(t)))
  .sort((a, b) => String(b.key).localeCompare(String(a.key)));

// Render
for (const g of groups) {
  const sample = g.rows[0];
  const dt = taskDoneDate(sample);
  dv.header(2, `${dt.toFormat('LLLL')} ${dt.toFormat('yyyy')}`);

  // Within month, group by day and sort newest day first
  const byDay = dv.array(g.rows)
    .groupBy(t => taskDoneDate(t).toISODate())
    .sort((a, b) => String(b.key).localeCompare(String(a.key)));

  for (const d of byDay) {
    const day = dv.luxon.DateTime.fromISO(d.key);
    dv.header(3, day.toFormat('cccc — LLL dd'));
    dv.taskList(d.rows, true);
  }
}

```
