# Weekly Planner (Rollover · v3)

> **Rollover**: open tasks show on the day and all later days until completed.
> **Archive**: completed tasks are preserved and listed below (today + by day for this week).

---

## Quick Add (ad-hoc tasks)
- [ ] Example ad-hoc task (no date; rolls every day)

---

## This Week (auto)
```dataviewjs
// ==== Week boundaries (Mon → Sun) ====
const today = dv.luxon.DateTime.local();
const monday = today.startOf('week');
const sunday = monday.plus({ days: 6 });
const days = Array.from({length: 7}, (_, i) => monday.plus({ days: i }));

// ==== Helpers ====
const toISO = (dt) => dt?.toISODate?.() ?? null;
const allOpen = dv.pages().flatMap(p => p.file.tasks).where(t => !t.completed);

function isUndated(t){ return !t.due && !t.scheduled; }

function tasksForDay(d) {
  const dayIso = d.toISODate();

  const matches = allOpen.where(t => {
    const dueIso = toISO(t.due);
    const schedIso = toISO(t.scheduled);
    const page = dv.page(t.path);
    const inWeeks = t.path.startsWith("Weeks/");
    const pageStart = page?.start ? dv.date(page.start) : null;

    if (isUndated(t)) {
      if (inWeeks) {
        // Only include undated week tasks if the week is not in the future
        return pageStart && pageStart <= sunday;
      } else {
        // Ad-hoc outside Weeks/: include every day
        return true;
      }
    } else {
      // Dated tasks appear when date <= current day
      const dueOk = dueIso && (dueIso <= dayIso);
      const schedOk = schedIso && (schedIso <= dayIso);
      return dueOk || schedOk;
    }
  });

  // De-duplicate
  const key = t => t.path + '|' + t.line;
  const map = new Map();
  for (const t of matches) map.set(key(t), t);
  return Array.from(map.values());
}

// ==== Render ====
for (const d of days) {
  dv.header(3, d.toFormat('cccc — LLL dd'));
  const items = tasksForDay(d);
  if (items.length === 0) dv.paragraph('_No tasks_');
  else dv.taskList(items, false);
}
```

---

## ✅ Completed Today
```dataviewjs
const today = dv.luxon.DateTime.local().toISODate();
const doneToday = dv.pages()
  .flatMap(p => p.file.tasks)
  .where(t => t.completed && t.completion && t.completion.toISODate() === today);

if (doneToday.length === 0) dv.paragraph('_Nothing completed yet today_');
else dv.taskList(doneToday, true);
```

---

## 🗂️ Completed This Week (by day)
```dataviewjs
const today = dv.luxon.DateTime.local();
const monday = today.startOf('week');
const days = Array.from({length: 7}, (_, i) => monday.plus({ days: i }));

const allDone = dv.pages().flatMap(p => p.file.tasks).where(t => t.completed && t.completion);

for (const d of days) {
  const iso = d.toISODate();
  const list = allDone.where(t => t.completion.toISODate && t.completion.toISODate() === iso);
  if (list.length > 0) {
    dv.header(3, d.toFormat('cccc — LLL dd'));
    dv.taskList(list, true);
  }
}
```
