
## 📅 Current Week – Tasks
**Dataview (recommended):**
```dataview
TASK
FROM "Weeks"
WHERE date(today) >= date(start) AND date(today) <= date(end)
GROUP BY file.link
```

---

## ⏳ Weeks Left (including this week)
```dataviewjs
let weeks = dv.pages('"Weeks"')
    .where(p => dv.date(p.start) >= dv.date("today"));
dv.header(3, weeks.length + " weeks left");
```

---

## ⚠️ Weeks Behind (past weeks with unfinished tasks)
```dataviewjs
let weeksBehind = dv.pages('"Weeks"')
    .where(p => dv.date(p.end) < dv.date("today"))        // only past weeks
    .where(p => p.file.tasks && p.file.tasks.where(t => !t.completed).length > 0);  // unfinished tasks

dv.header(3, weeksBehind.length + " weeks behind");
```

---

## 🔜 Upcoming Week – Next Week's Tasks
```dataview
TASK
FROM "Weeks"
WHERE date(start) > date(today)
SORT start ASC
LIMIT 1
```

---

## Tasks plugin (optional alternative):
```tasks
not done
path includes Weeks/
starts on or before this week
starts on or after this week
```
