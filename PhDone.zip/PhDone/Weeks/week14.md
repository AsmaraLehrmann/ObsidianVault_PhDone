---
week: 14
start: 2025-11-24
end: 2025-11-30
---
# Week 14

## Tasks

## Notes
- Context, goals, and focus for this week.
