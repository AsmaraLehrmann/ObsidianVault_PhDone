---
week: 4
start: 2025-09-15
end: 2025-09-21
---
# Week 4

## Tasks

## Notes

Context, goals, and focus for this week.