---
week: 36
start: 2026-04-27
end: 2026-05-03
---
# Week 36

## Tasks

## Notes
- Context, goals, and focus for this week.
