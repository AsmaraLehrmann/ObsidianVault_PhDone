---
week: 13
start: 2025-11-17
end: 2025-11-23
---
# Week 13

## Tasks

## Notes
- Context, goals, and focus for this week.
