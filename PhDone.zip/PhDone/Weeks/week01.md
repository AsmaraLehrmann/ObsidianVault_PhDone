---
week: 1
start: 2025-08-25
end: 2025-08-31
---
# Week 1

## Tasks

## Notes
Context, goals, and focus for this week.
