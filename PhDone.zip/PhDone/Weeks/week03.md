---
week: 3
start: 2025-09-08
end: 2025-09-14
---
# Week 3

## Tasks

## Notes
-Context, goals, and focus for this week.